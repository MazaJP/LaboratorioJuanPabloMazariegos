﻿using L11;

class Program {
    public static void Main(string[] args) {
        //Ejercicio 1
        Calculadora calculadora = new Calculadora();
        calculadora.IniciarOpciones();

        //Ejercicio 2
        Personaje personaje = new Personaje();
        personaje.IniciarOpciones();
    }
}
﻿
using System.Data;
using Microsoft.VisualBasic;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1");
        string entrada;
        int opcion = 0;
        do
        {
            Console.WriteLine("ingrese un numero del 1 al 4");
            Console.WriteLine("1. Sumatoria");
            Console.WriteLine("2. Factorial");
            Console.WriteLine("3. Tablas");
            Console.WriteLine("4. Salir");
            entrada = Console.ReadLine();
            try
            {
                opcion = int.Parse(entrada);
            }

            catch (FormatException)
            {
                Console.WriteLine("Error, debe ingresar un numero");
            }
        }
        while (opcion == 4);

        switch (opcion)
        {
            case 1:
                Console.WriteLine("ingrese un numero positivo");
                string entradanum = Console.ReadLine();
                int n =0;
                
                try
                {
                    n = int.Parse(entradanum);
                }

                catch (FormatException)
                {
                    Console.WriteLine("Error, debe ingresar un numero");
                }
                int i =1;
                int sumatoria = 0;
                while(i <= n )
                {
                    sumatoria +=i;
                    i++;
                }
                Console.WriteLine($"sumatoria: {sumatoria}");
                break;
            case 2:
               
                Console.WriteLine("ingrese un numero positivo");
                string entradaf = Console.ReadLine();
                int j =0;
                
                try
                {
                    j = int.Parse(entradaf);
                }

                catch (FormatException)
                {
                    Console.WriteLine("Error, debe ingresar un numero");
                }
                int r =1;
                int factorial = 1;
                while(r <= j )
                {
                   factorial *=r;
                    r++;
                }
                Console.WriteLine($"Factorial: {factorial}");
                break;
            case 3:
                string titulo = "\t";
              for (int ititulo = 1; ititulo <= 10; ititulo++)
              {
                titulo += ititulo + "\t";
              }
              Console.WriteLine(titulo);

              string fila = "";

              for (int ifila = 1; ifila <= 10; ifila++)
              {
                fila = ifila + "\t";
                for (int multipo = 1; multipo <= 10; multipo++)
                {
                    fila += ifila * multipo + "\t";

                }
               Console.WriteLine(fila);
               
              }
                break;
            case 4:
                break;
            default:
                Console.WriteLine("Error, debe ingresar un numero");
                break;
        }
    }
}


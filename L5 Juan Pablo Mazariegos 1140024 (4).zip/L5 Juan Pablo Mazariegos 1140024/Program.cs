﻿
using System;

class Program
{
    static void Main(string[] args)
    {
         Console.WriteLine("Ejercicio 1");
        int numfibonacci;
        bool t1 = false;
        bool npositivo = false;

        int x = 0;
        int h = 1;
        int c = 0;
        int i = 2;
        string resultado = "";

        Console.WriteLine("Ingrese un número mayor a 0");

        if (!int.TryParse(Console.ReadLine(), out numfibonacci))
        {
            do
            {
                Console.WriteLine("Ingrese un número mayor a 0");
                t1 = int.TryParse(Console.ReadLine(), out numfibonacci);
                if (t1)
                {
                    if (numfibonacci > 0)
                    {
                        npositivo = true;
                    }
                }
            } while (!t1 || !npositivo);
        }

        if (numfibonacci > 0)
        {
            resultado = x + ", ";

            if (numfibonacci > 1)
            {
                resultado += h + ", ";

                while (i < numfibonacci)
                {
                    c = x + h;
                    resultado += c + ", ";
                    x = h;
                    h = c;
                    i = i + 1;
                }
            }

          Console.WriteLine($"Su sucesión es: {resultado.TrimEnd(',', ' ')}");
        }
        else
        {
            Console.WriteLine($"Su número es: {resultado}");
        }

         Console.WriteLine("Ejercicio 2");
int a;
int b;
int m = 0;
int o;
int p = 0;
double q = 0;
int r = 1;
double s = 0;
double t = 0;
double u = 1;
string v = "";
string w = "";

Console.Write("Ingrese su primer valor: ");
a = int.Parse(Console.ReadLine());
Console.Write("Ingrese su segundo valor: ");
b = int.Parse(Console.ReadLine());
Console.Write("Ingrese su tercer valor: ");
o = int.Parse(Console.ReadLine());

Console.WriteLine("A continuación se operara de esta forma (x/1) + (x/2) + ... + (x/o)");
while (p != o)
{
    q = a / r;
    v += q + ",";
    r++;
    p++;
}
Console.WriteLine(v);
p = 0;
Console.WriteLine("A continuación se operara de esta forma (x/2^1) + (x/2^2) + ... + (x/2^o)");
while (p != o)
{
    q=a/(2*u);
    w += q + ",";
    u = u*2;
    p++;
}
Console.WriteLine(w);

Console.WriteLine("A continuación se operara de esta forma xᵐ·aᵒ⁻ᵐ");
s = Math.Pow(a, m);
t = Math.Pow(b, (o - m));
q = s*t;
Console.WriteLine(q);

   
   } 
}


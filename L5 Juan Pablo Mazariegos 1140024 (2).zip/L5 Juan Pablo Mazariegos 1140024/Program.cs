﻿using System.Data;
using Microsoft.VisualBasic;
using System;

class Program
{
    static void Main(string[] args)
    {
        Automovil objautomovil = new Automovil();
        Console.WriteLine(objautomovil.InfoAuto());
    }
}



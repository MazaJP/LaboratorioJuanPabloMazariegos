﻿//Luis Diego López - 1090824
//Juan Pablo Mazariegos - 1140024

using Proyecto1;

class Program {
    
    public static void Main(string[] args) {
        // Inicia el menú de la maquina
        Maquina  maquina = new Maquina();
        maquina.IniciarMaquina();
    }        
}
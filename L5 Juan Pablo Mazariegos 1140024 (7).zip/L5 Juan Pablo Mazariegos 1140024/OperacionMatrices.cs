﻿namespace L5_Juan_Pablo_Mazariegos_1140024;

class OperacionesMatrices
{
public class OperacionesMatriz
{
    public int[,] matriz = new int[0, 0];

    public void OperacionesMatrices()
    {
    }

    public void CrearMatriz()
    {
        int cantidadFilas = 0;
        int cantidadCols = 0;

        Console.WriteLine("Ingrese la cantidad de filas :");
        while (!int.TryParse(Console.ReadLine(), out cantidadFilas) || cantidadFilas <= 0)
        {
            Console.WriteLine("Ingrese un valor válido para la cantidad de filas (entero positivo):");
        }

        Console.WriteLine("Ingrese la cantidad de columnas :");
        while (!int.TryParse(Console.ReadLine(), out cantidadCols) || cantidadCols <= 0)
        {
            Console.WriteLine("Ingrese un valor válido para la cantidad de columnas (entero positivo):");
        }

        matriz = new int[cantidadFilas, cantidadCols];
    }

    public void IngresarDatosMatriz()
    {
        for (int fila = 0; fila < matriz.GetLength(0); fila++)
        {
            for (int columna = 0; columna < matriz.GetLength(1); columna++)
            {
                Console.WriteLine($"Ingrese valor para la posición [{fila}][{columna}]:");
                while (!int.TryParse(Console.ReadLine(), out matriz[fila, columna]))
                {
                    Console.WriteLine("Ingrese un valor :");
                }
            }
        }
    }

    public int[,] MultiplicaciónMatrizEscalar(int escalar)
    {
        int[,] matrizMultiplicada = new int[matriz.GetLength(0), matriz.GetLength(1)];

        for (int fila = 0; fila < matriz.GetLength(0); fila++)
        {
            for (int columna = 0; columna < matriz.GetLength(1); columna++)
            {
                matrizMultiplicada[fila, columna] = matriz[fila, columna] * escalar;
            }
        }

        return matrizMultiplicada;
    }

    public int[,] ContarMenoresEnFilas(int valor)
    {
        int[,] resultado = new int[matriz.GetLength(0), 1];

        for (int fila = 0; fila < matriz.GetLength(0); fila++)
        {
            int contador = 0;
            for (int columna = 0; columna < matriz.GetLength(1); columna++)
            {
                if (matriz[fila, columna] < valor)
                {
                    contador++;
                }
            }
            resultado[fila, 0] = contador;
        }

        return resultado;
    }
}

}
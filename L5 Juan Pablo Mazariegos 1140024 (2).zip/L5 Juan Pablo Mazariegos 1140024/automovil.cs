using System.Reflection.Metadata.Ecma335;
using System;
public class Automovil
{
    private int modelo = 2019;
    private double precio = 10000.00;
    private string marca = "";
    private double CambioDolar = 7.50;
    private double descuento = 0.00;
    private bool disponible = false;

    public Automovil()
    {

    }

    public double UnPrecio()
    {
        return precio;
    }

    public string UnaMarca()
    {
        return marca;
    }

    public int UnModelo()
    {
        return modelo;
    }

    public double UnTipoCambio()
    {
        return CambioDolar;
    }

    public bool Disponibilidad()
    {
        return disponible;
    }

    public double CambioDinero()
    {
        return precio * CambioDolar;
    }

    public string InfoAuto()
    {
        return "Marca: " + UnaMarca() + ", Modelo: " + UnModelo() + ", Precio de venta Q: " + UnPrecio() + ", Precio en dólares: " + CambioDinero() + ", Disponible: " + Disponibilidad() + ".";
    }
}




